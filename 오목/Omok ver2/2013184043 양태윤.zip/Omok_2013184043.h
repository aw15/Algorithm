#pragma once
#include"judgment.h"



void WhiteDefence_2013184043(int x, int y);
void WhiteAttack_2013184043(int *x, int *y);
void BlackDefence_2013184043(int x, int y);
void BlackAttack_2013184043(int *x, int *y);







